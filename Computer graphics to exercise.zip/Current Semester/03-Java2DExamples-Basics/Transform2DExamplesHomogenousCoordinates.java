package lecture03_2DGraphics;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JFrame;

public class Transform2DExamplesHomogenousCoordinates extends JFrame {
	public Transform2DExamplesHomogenousCoordinates(){
		super("Simple 2D Examples");
		setSize(500,500);
		setVisible(true);
	}
	
	public static void main(String[] args) {
		
		new Transform2DExamplesHomogenousCoordinates();
	}
	
	public void paint(Graphics g) {
		Graphics2D g2d = (Graphics2D)g;
		
		//Constructing first 2D affine transform
		//[ x']   [  m00  m01  m02  ] [ x ]   [ m00x + m01y + m02 ]
	    //[ y'] = [  m10  m11  m12  ] [ y ] = [ m10x + m11y + m12 ]
	    //[ 1 ]   [   0    0    1   ] [ 1 ]   [         1         ]
		double m00,m01,m02,m10,m11,m12;
		
		//Translation
		m02 = 250.0;
		m12 = 0.0;
		
		//Rotation matrix
		m00 = 1.0;		m01 = 0.0;
		m10 = 0.0;		m11 = 1.0;
		
		java.awt.geom.AffineTransform my2DTransform 
		  = new java.awt.geom.AffineTransform(m00, m10, m01, m11, m02, m12);
		
		//Constructing second 2D affine transform
		
		//Translation
		m02 = 0.0;
		m12 = 0.0;
				
		//Rotation matrix / 45 degree turn
		m00 = 0.707; 		m01 = -0.707;
		m10 = 0.707;		m11 = 0.707;
		
		java.awt.geom.AffineTransform my2DTransform2 
		  = new java.awt.geom.AffineTransform(m00, m10, m01, m11, m02, m12);
		
		my2DTransform.concatenate(my2DTransform2);
		
		//apply transform
		g2d.setTransform(my2DTransform);
		
		//draw rectangle
		g2d.setColor(Color.blue);
		g2d.fillRect(110, 110, 180, 280);
		
		
		
		
		
	}
}

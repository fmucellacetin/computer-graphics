package lecture03_2DGraphics;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JFrame;

public class Transform2DExamples extends JFrame {
	public static void main(String[] args) {
		new Transform2DExamples();
	}
	
	public Transform2DExamples(){
		super("Simple 2D Examples");
		setSize(500,500);
		setVisible(true);
	}
	
	public void paint(Graphics g) {
		Graphics2D g2d = (Graphics2D)g;
			
		java.awt.geom.AffineTransform my2DTransform = new java.awt.geom.AffineTransform();
		my2DTransform.rotate(Math.toRadians(50));
		my2DTransform.translate(100,50);
		
		
		
		//apply transform
		g2d.setTransform(my2DTransform);
		
		//draw rectangle
		g2d.setColor(Color.blue);
		g2d.fillRect(210, 210, 50, 50);		
		
	}
}

package lecture03_2DGraphics;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import javax.swing.JFrame;

public class Graphics2DLoadImages extends JFrame {

	public static void main(String[] args) {
		new Graphics2DLoadImages();

	}
	
	public Graphics2DLoadImages(){
		super("Simple 2D Image Example");
		setSize(500,500);
		setVisible(true);
	}
	
	public void paint(Graphics g) {
	
		Graphics2D g2d = (Graphics2D)g;
			
		//Load and draw image
		BufferedImage img = null;
	    try {
	        img =  ImageIO.read(new java.io.File("C:/demos/demo-images/ct-screenshot.png"));
	    } catch (Exception e) {System.out.println(e.toString());}
	    if(img != null)	g2d.drawImage(img, 20, 50, 200, 200, 0, 0, img.getWidth(null), img.getHeight(null), null);
	    
	}

}


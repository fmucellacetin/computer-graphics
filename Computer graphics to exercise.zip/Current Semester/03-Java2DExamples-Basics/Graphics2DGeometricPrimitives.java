package lecture03_2DGraphics;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.QuadCurve2D;
import javax.swing.JFrame;

public class Graphics2DGeometricPrimitives extends JFrame {
	
public static void main(String[] args) {
		new Graphics2DGeometricPrimitives();

}
	
public Graphics2DGeometricPrimitives(){
	super("2D Geometric Primitive Examples");
	setSize(500,500);
	setVisible(true);
}

public void paint(Graphics g) {

	Graphics2D g2d = (Graphics2D)g;
	//g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	
	//Set Background
	g2d.setColor(Color.white);
	g2d.fillRect(0, 0, 500, 500);
	g2d.setColor(Color.black);
	
	//g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	
	//Draw line
	g2d.drawLine(20, 40, 120, 40);
	
	//Draw curve (quadric)
	QuadCurve2D q = new QuadCurve2D.Float();
	q.setCurve(20, 60, 70, 80, 120, 60 );
	g2d.draw(q);
	
	//Draw rectangle
	g2d.drawRect(20, 80, 100, 50);
	
	//Draw ellipse
	g2d.draw(new Ellipse2D.Double(20, 150,
            100,
            60));
	
	// draw GeneralPath (polygon)
	int x1Points[] = {20, 120, 20, 120};
	int y1Points[] = {220, 270, 270, 220};
	GeneralPath polygon = 
	        new GeneralPath(GeneralPath.WIND_EVEN_ODD,
	                        x1Points.length);
	polygon.moveTo(x1Points[0], y1Points[0]);

	for (int index = 1; index < x1Points.length; index++) {
	        polygon.lineTo(x1Points[index], y1Points[index]);
	};

	polygon.closePath();
	g2d.draw(polygon);
}

}
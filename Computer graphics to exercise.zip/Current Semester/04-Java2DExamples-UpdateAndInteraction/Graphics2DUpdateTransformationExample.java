package lecture04_2DGraphics;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.Timer;

public class Graphics2DUpdateTransformationExample extends Frame implements ActionListener  {
	
	Timer timer;
	
	int rotation;
	
	public static void main(String[] args) {	
		new Graphics2DUpdateTransformationExample();
	}
	
	public Graphics2DUpdateTransformationExample(){
		super("2D Examples: use Transformations");
		setSize(500,500);
		setVisible(true);
		
		//Add Windows-Listener to make awt.frame closable
		this.addWindowListener(new WindowAdapter() { 
				public void windowClosing(WindowEvent we) {
					dispose();
				}
	     	}
		);
		
		//Set up timer to drive animation events.
        timer = new Timer(100, this);
        timer.setInitialDelay(0);
        timer.start(); 
        
        rotation = 0;
	}
	
	public void paint(Graphics g) {

		Graphics2D g2d = (Graphics2D)g;		
		g2d.setColor(Color.blue);
		//g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
				
		java.awt.geom.AffineTransform myTransformation = new java.awt.geom.AffineTransform();
		myTransformation.translate(200, 200);
		myTransformation.rotate(Math.toRadians(rotation));
		g2d.setTransform(myTransformation);
		
		g2d.fillRect(-25, -10, 50, 20);
		
		rotation++;
		if (rotation==361) rotation = 0;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		repaint();
	}
}
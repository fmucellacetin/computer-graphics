package lecture04_2DGraphics;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.Timer;

public class Graphics2DUpdateExample extends Frame implements ActionListener  {
	
	Timer timer;
	
	int length;
	
	public static void main(String[] args) {
		new Graphics2DUpdateExample();
	}
	
	public Graphics2DUpdateExample(){
		super("Simple 2D Examples");
		setSize(500,500);
		setVisible(true);
		
		//Add Windows-Listener to make awt.frame closable
				this.addWindowListener(new WindowAdapter() { 
						public void windowClosing(WindowEvent we) {
							dispose();
						}
			     	}
				);
		
		//Set up timer to drive animation events.
        timer = new Timer(100, this);
        timer.setInitialDelay(0);
        timer.start(); 
        
        length = 0;
	}
	
	public void paint(Graphics g) {

		Graphics2D g2d = (Graphics2D)g;
		java.awt.geom.AffineTransform myTransformation = new java.awt.geom.AffineTransform();
		myTransformation.scale(2, 2);
		g2d.setTransform(myTransformation);
		g2d.drawLine(120, 200, length, 200);
		length++;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		repaint();
	}
}

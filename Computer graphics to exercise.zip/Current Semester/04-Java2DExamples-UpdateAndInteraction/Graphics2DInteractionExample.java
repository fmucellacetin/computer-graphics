package lecture04_2DGraphics;
import java.awt.AWTEvent;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.AWTEventListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Graphics2DInteractionExample extends Frame implements AWTEventListener   {
		
	int positionX,positionY;
	
	public static void main(String[] args) {	
		new Graphics2DInteractionExample();
	}
	
	public Graphics2DInteractionExample(){
		//Initialize awt.frame object
		super("2D Examples: Keyboard interaction");
		setSize(500,500);
		setVisible(true);
		//Add Windows-Listener to make awt.frame closable
		this.addWindowListener(new WindowAdapter() { 
				public void windowClosing(WindowEvent we) {
					dispose();
				}
	     	}
		);
		
		//Add event listener for keyboard interaction		
		this.getToolkit().addAWTEventListener(this, AWTEvent.KEY_EVENT_MASK);
				
		//initialize member variables to store object position		
		positionX=150;
		positionY=150;
		
	}
	
	public void paint(Graphics g) {

		Graphics2D g2d = (Graphics2D)g;	
		g2d.setColor(Color.blue);						
		g2d.fillRect(positionX,positionY, 50, 20);
		
	}


	@Override
	public void eventDispatched(AWTEvent event) {
	    if(event instanceof KeyEvent){
	      KeyEvent key = (KeyEvent)event;
	      switch(key.getKeyCode())
	      {
	      case 38: //Key_up	  
	    	  positionY--;
	    	  break;
	      case 40: //Key_down
	    	  positionY++;
	    	  break;
	      case 37: //Key_left
	    	  positionX--;
	    	  break;
	      case 39: //Key_right
	    	  positionX++;
	    	  break;
	      case 27: //ESC
	    	  System.exit(0);    
	    
	      }
	      key.consume();
	    }
	    repaint();
	  }
}


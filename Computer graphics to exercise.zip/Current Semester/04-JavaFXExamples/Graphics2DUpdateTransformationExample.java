import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.transform.Affine;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Graphics2DUpdateTransformationExample extends Application {

    private Canvas canvas;
    private int rotation;

    public static void main(String[] args) {
		Application.launch(args);
	}
    
    @Override
    public void start(Stage primaryStage) throws Exception {

        rotation = 0;
        canvas = new Canvas(400, 400);
        draw(canvas.getGraphicsContext2D());

        Timeline timeline = new Timeline();
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.getKeyFrames().add(
                new KeyFrame(Duration.millis(100),
                event -> draw(canvas.getGraphicsContext2D()))
        );
        timeline.play();

        primaryStage.setTitle("2D Examples: use Transformations");
        primaryStage.setScene(new Scene(new Group(canvas)));
        primaryStage.show();
        canvas.requestFocus();
    }

    private void draw(GraphicsContext context) {
        context.setStroke(Color.BLUE);
        context.setFill(Color.BLUE);

        context.save();
        context.translate(200, 200);
        context.transform(new Affine(new Rotate(rotation, 0, 0)));
        context.clearRect(-26, -11, 52, 22);
        context.fillRect(-25, -10, 50, 20);
        context.restore();

        rotation++;
        if(rotation > 360) rotation = 0;

    }
}


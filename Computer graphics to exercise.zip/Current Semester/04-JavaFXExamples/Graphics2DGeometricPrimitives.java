

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Graphics2DGeometricPrimitives extends Application {

    private Canvas canvas;

	public static void main(String[] args) {
		Application.launch(args);
	}
	
    @Override
    public void start(Stage primaryStage) throws Exception {

        canvas = new Canvas(400, 400);
        draw(canvas.getGraphicsContext2D());

        primaryStage.setTitle("2D Geometric Primitive Examples");
        primaryStage.setScene(new Scene(new Group(canvas)));
        primaryStage.show();
    }

    private void draw(GraphicsContext context) {
        context.setStroke(Color.RED);
        context.setFill(Color.BLUE);


        //Draw line
        context.strokeLine(20, 40, 120, 40);

        //Draw curve
        context.beginPath();
        context.moveTo(20, 60);
        context.quadraticCurveTo(70, 80, 120, 60);
        context.stroke();

        //Draw rectangle
        context.strokeRect(20, 80, 100, 50);

        //Draw ellipse
        context.strokeOval(20, 150, 100, 60);

        //Draw general path
        int x1Points[] = {20, 120, 20, 120};
        int y1Points[] = {220, 270, 270, 220};
        context.beginPath();
        context.moveTo(x1Points[0], y1Points[0]);
        for(int i=1; i < x1Points.length; i++)
            context.lineTo(x1Points[i], y1Points[i]);
        context.closePath();
        context.stroke();

    }
}

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Graphics2DInteractionExample extends Application {


	public static void main(String[] args) {
		Application.launch(args);
	}
	
    private Canvas canvas;

    private int posX;
    private int posY;

    @Override
    public void start(Stage primaryStage) throws Exception {

        posX = 50;
        posY = 50;

        canvas = new Canvas(400, 400);
        draw(canvas.getGraphicsContext2D());

        canvas.setOnKeyPressed(event -> {
            switch (event.getCode()) {
                case UP: posY--; break;
                case DOWN: posY++; break;
                case LEFT: posX--; break;
                case RIGHT: posX++; break;
            }
            draw(canvas.getGraphicsContext2D());
        });

        primaryStage.setTitle("2D Examples: Keyboard interaction");
        primaryStage.setScene(new Scene(new Group(canvas)));
        primaryStage.show();
        canvas.requestFocus();
    }

    private void draw(GraphicsContext context) {
        context.setStroke(Color.RED);
        context.setFill(Color.BLUE);

        context.clearRect(posX-1, posY-1, 52, 22);
        context.fillRect(posX, posY, 50, 20);

    }
}

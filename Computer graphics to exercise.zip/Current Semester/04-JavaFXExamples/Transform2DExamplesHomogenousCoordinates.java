import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.transform.Affine;
import javafx.stage.Stage;

public class Transform2DExamplesHomogenousCoordinates extends Application {

	private Canvas canvas;

    public static void main(String[] args) {
        Application.launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {

        canvas = new Canvas(500, 500);
        draw(canvas.getGraphicsContext2D());

        primaryStage.setTitle("Simple 2D Examples");
        primaryStage.setScene(new Scene(new Group(canvas)));
        primaryStage.show();
    }

    private void draw(GraphicsContext context) {
        context.setStroke(Color.RED);
        context.setFill(Color.BLUE);

        //Constructing first 2D affine transform
        //[ x']   [  m00  m01  m02  ] [ x ]   [ m00x + m01y + m02 ]
        //[ y'] = [  m10  m11  m12  ] [ y ] = [ m10x + m11y + m12 ]
        //[ 1 ]   [   0    0    1   ] [ 1 ]   [         1         ]
        double m00, m01, m02, m10, m11, m12;

        //Translation
        m02 = 250.0;
        m12 = 0.0;

        //Rotation matrix
        m00 = 1.0;		m01 = 0.0;
        m10 = 0.0;		m11 = 1.0;

        Affine my2DTransform = new Affine(m00, m01, m02, m10, m11, m12);

        //Constructing second 2D affine transform

        //Translation
        m02 = 0.0;
        m12 = 0.0;

        //Rotation matrix / 45 degree turn
        m00 = 0.707; 		m01 = -0.707;
        m10 = 0.707;		m11 = 0.707;

        Affine my2DTransform2 = new Affine(m00, m01, m02, m10, m11, m12);

        my2DTransform.append(my2DTransform2);

        context.save();
        context.transform(my2DTransform);
        context.fillRect(110, 110, 180, 280);
        context.restore();

    }
}
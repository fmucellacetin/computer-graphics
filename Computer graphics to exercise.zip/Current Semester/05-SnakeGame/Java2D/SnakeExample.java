package SnakeExample;

import java.awt.AWTEvent;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.AWTEventListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.Timer;

public class SnakeExample extends Frame implements AWTEventListener, ActionListener   {
	
	private static final long serialVersionUID = 1L;
	
	int width = 200;
	int height = 200;
	int snakeStartSize = 20;
	
	Timer timer;
	
	enum movingDirection {LEFT,UP,RIGHT,DOWN};
	
	movingDirection currentSnakeMovingDirection = movingDirection.RIGHT;
	
	int positionX = 50;
	int positionY = 50;
	int stopSnakeShrinking = 0;
	int score;
	
	Random myRandomGenerator = new Random();
	
	ArrayList<Point2D.Float> snake;
	
	Point2D.Float target = new Point2D.Float(width/2,height/2);
	
	
	public static void main(String[] args) {	
		new SnakeExample();
	}
	
	public SnakeExample(){
		//Initialize awt.frame object
		super("Snake game");
		setSize(width*2,height*2);
		setVisible(true);
		//Add Windows-Listener to make awt.frame closable
		this.addWindowListener(new WindowAdapter() { 
				public void windowClosing(WindowEvent we) {
					timer.stop();
					dispose();
				}
	     	}
		);
		
		//Set up timer to drive animation events.
        timer = new Timer(50, this);
        timer.setInitialDelay(0);
        timer.start();
        
		//Add event listener for keyboard interaction		
		this.getToolkit().addAWTEventListener(this, AWTEvent.KEY_EVENT_MASK);
		
		reset();
		
				
	}
	
	public void reset()
	{
		snake = new ArrayList<Point2D.Float>();
		Point2D.Float newPoint = new Point2D.Float(50,50);
		for (int i = 0; i < snakeStartSize; i++)
		  {
		  snake.add(newPoint);
		  newPoint.x++;
		  }
		currentSnakeMovingDirection = movingDirection.RIGHT;
		target = new Point2D.Float(width/2,height/2);
		score = 0;
	}
		

	
	public void paint(Graphics g) {

		Graphics2D g2d = (Graphics2D)g;
		//g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		java.awt.geom.AffineTransform my2DTransform = new java.awt.geom.AffineTransform();
		my2DTransform.scale(2, 2);
		g2d.setTransform(my2DTransform);
		g2d.setColor(Color.blue);
		
		//creates a new polyline to draw the snake
		if(snake!=null && !snake.isEmpty())
		{
			int[] x = new int[snake.size()];
			int[] y = new int[snake.size()];
			for (int i=0; i<snake.size(); i++)
			{
				x[i] = (int) snake.get(i).getX();
				y[i] = (int) snake.get(i).getY();
			}
			g2d.drawPolyline(x, y, snake.size());
			
		}
		
		//draws border, game information, etc.
		g2d.setColor(Color.red);
		g2d.drawRect((int)target.x-5,(int)target.y-5,10,10);
		g2d.setColor(Color.gray);
		g2d.drawRect(20,40,width-40,height-60);
		g2d.drawString("Score:     " + score, 20, 30); //draws the score
		g2d.setColor(Color.orange);
		g2d.drawOval(68, 19, 20, 13);
				
	}


	@Override
	public void eventDispatched(AWTEvent event) {
	    if((event instanceof KeyEvent) && (event.getID()==KeyEvent.KEY_PRESSED)){
	      KeyEvent key = (KeyEvent)event;
	      switch(key.getKeyCode())
	      {
	      case 37: //Key_left
	    	  switch (currentSnakeMovingDirection)
	    	  {
	    	  case LEFT:
	    		  currentSnakeMovingDirection = movingDirection.DOWN;
	    		  break;
	    	  case UP:
	    		  currentSnakeMovingDirection = movingDirection.LEFT;
	    		  break;
	    	  case RIGHT:
	    		  currentSnakeMovingDirection = movingDirection.UP;
	    		  break;
	    	  case DOWN:
	    		  currentSnakeMovingDirection = movingDirection.RIGHT;
	    		  break;
	    	  }
	    	  break;
	      case 39: //Key_right
	    	  switch (currentSnakeMovingDirection)
	    	  {
	    	  case LEFT:
	    		  currentSnakeMovingDirection = movingDirection.UP;
	    		  break;
	    	  case UP:
	    		  currentSnakeMovingDirection = movingDirection.RIGHT;
	    		  break;
	    	  case RIGHT:
	    		  currentSnakeMovingDirection = movingDirection.DOWN;
	    		  break;
	    	  case DOWN:
	    		  currentSnakeMovingDirection = movingDirection.LEFT;
	    		  break;
	    	  }
	    	  break;
	      case 27: //ESC
	    	  System.exit(0);    
	    
	      }
	      key.consume();
	    }
	  }

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(snake!=null && !snake.isEmpty())
		{
		  Point2D.Float nextSnakeElement = new Point2D.Float();
		  Point2D.Float lastSnakeElement = snake.get(snake.size()-1);
		  switch (currentSnakeMovingDirection)
	  	  {
	  	  case LEFT:
	  		  nextSnakeElement.setLocation(lastSnakeElement.getX()-1,lastSnakeElement.getY());
	  		  break;
	  	  case UP:
	  		  nextSnakeElement.setLocation(lastSnakeElement.getX(),lastSnakeElement.getY()+1);
	  		  break;
	  	  case RIGHT:
	  		  nextSnakeElement.setLocation(lastSnakeElement.getX()+1,lastSnakeElement.getY());
	  		  break;
	  	  case DOWN:
	  		  nextSnakeElement.setLocation(lastSnakeElement.getX(),lastSnakeElement.getY()-1);
	  		  break;
	  	  }	
		  snake.add(nextSnakeElement);
		  if (checkBorderHit()) reset();
		  if (checkSnakeHit()) reset();
		  if (checkTargetHit()) 
			  {
			  stopSnakeShrinking = 10;
			  score++;
			  newRandomTarget();
			  }
		  if (stopSnakeShrinking==0) snake.remove(0);
		  else stopSnakeShrinking--;
		  repaint();
		}
	}
	
	public boolean checkTargetHit(){
		Point2D.Float lastPoint = snake.get(snake.size()-1);
		if (lastPoint.x > (target.x-5) &&
		    lastPoint.x < (target.x+5) &&
		    lastPoint.y > (target.y-5) &&
		    lastPoint.y < (target.y+5))
		    return true;
		else 
			return false;
	}
	
	public boolean checkSnakeHit(){
		Point2D.Float lastPoint = snake.get(snake.size()-1);
		for (int i=0; i<snake.size()-2; i++) 
		{
			if (lastPoint.equals(snake.get(i))) return true;
		}
		return false;
	}
	
	public boolean checkBorderHit(){
		if (snake.get(snake.size()-1).x < 20) return true;
		else if (snake.get(snake.size()-1).y < 40) return true;
		else if (snake.get(snake.size()-1).x > width-20) return true;
		else if (snake.get(snake.size()-1).y > height-20) return true;
		else return false;
	}
	
	public void newRandomTarget()
	{
		int posX = (int)(myRandomGenerator.nextFloat()*(width-50))+25;
		int posY = (int)(myRandomGenerator.nextFloat()*(height-70))+45;
		target = new Point2D.Float(posX,posY);
	}
}
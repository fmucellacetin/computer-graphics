import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.geometry.Point2D;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.ArrayList;

public class SnakeExample extends Application {

	public static void main(String[] args) {
		Application.launch(args);
	}
	
    private Canvas canvas;

    private ArrayList<Point2D> snake;

    private enum Direction { LEFT, UP, RIGHT, DOWN }
    private Direction movingDirection;

    @Override
    public void start(Stage primaryStage) throws Exception {
        snake = new ArrayList<>();
        snake.add(new Point2D(50, 50));
        movingDirection = Direction.RIGHT;

        canvas = new Canvas(500, 500);
        draw(canvas.getGraphicsContext2D());

        canvas.setOnKeyPressed(this::control);

        Timeline timeline = new Timeline();
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.getKeyFrames().add(
                new KeyFrame(Duration.millis(100),
                        event -> {
                            update();
                            draw(canvas.getGraphicsContext2D());
                        })
        );
        timeline.play();

        primaryStage.setTitle("2D Examples: Keyboard interaction");
        primaryStage.setScene(new Scene(new Group(canvas)));
        primaryStage.show();
        canvas.requestFocus();

    }

    private void control(KeyEvent keyEvent) {
        switch (keyEvent.getCode()) {
            case LEFT:
                switch (movingDirection) {
                    case UP:
                        movingDirection = Direction.LEFT; break;
                    case LEFT:
                        movingDirection = Direction.DOWN; break;
                    case DOWN:
                        movingDirection = Direction.RIGHT; break;
                    case RIGHT:
                        movingDirection = Direction.UP; break;
                }
                break;
            case RIGHT:
                switch (movingDirection) {
                    case UP:
                        movingDirection = Direction.RIGHT; break;
                    case LEFT:
                        movingDirection = Direction.UP; break;
                    case DOWN:
                        movingDirection = Direction.LEFT; break;
                    case RIGHT:
                        movingDirection = Direction.DOWN; break;
                }
                break;
            case ESCAPE:
                canvas.getScene().getWindow().hide();
                break;
        }
        keyEvent.consume();
    }

    private void draw(GraphicsContext context) {
        context.setStroke(Color.BLUE);

        if(!snake.isEmpty()) {
            context.beginPath();
            context.moveTo(snake.get(0).getX(), snake.get(0).getY());
            snake.forEach(point -> {
                context.lineTo(point.getX(), point.getY());

            });
            context.stroke();
        }
    }

    private void update() {
        if(!snake.isEmpty()) {
            Point2D endPoint = snake.get(snake.size()-1);

            switch (movingDirection) {
                case UP: snake.add(new Point2D(endPoint.getX(), endPoint.getY()+10)); break;
                case LEFT: snake.add(new Point2D(endPoint.getX()-10, endPoint.getY())); break;
                case DOWN: snake.add(new Point2D(endPoint.getX(), endPoint.getY()-10)); break;
                case RIGHT: snake.add(new Point2D(endPoint.getX()+10, endPoint.getY())); break;
            }
        }
    }

}
